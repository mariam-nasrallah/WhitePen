import BaseWhitePen from "./baseWhitePen";
import { ISnykLib } from "./interfaces";

export default class WhitePenLib extends BaseWhitePen implements ISnykLib{
    
}