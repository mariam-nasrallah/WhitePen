export const WHITEPEN_START_COMMAND = 'whitepen.start';
export const WHITEPEN_LOGIN = 'whitepen.login';
export const WHITEPEN_LOGOUT = 'whitepen.logout';
export const WHITEPEN_SCAN_DEP = 'whitepen.scan.dep';
export const WHITEPEN_SCAN_CODE = 'whitepen.scan.code';
export const WHITEPEN_SET_TOKEN = 'whitepen.set.token';
export const WHITEPEN_CVES = 'whitepen.cves';



export const WHITEPEN_CONTEXT_PREFIX = 'whitepen:';